package com.grinleaf.onesightdiaryplanner

data class TutorialImage constructor(var imgId:Int)
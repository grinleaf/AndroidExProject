package com.grinleaf.onesightdiaryplanner

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.RecyclerView

//class DailyNoteAdapter(val context:Context, val dailyItems:MutableList<DailyItem>):RecyclerView.Adapter<>() {
//    inner class VH(itemView: View):RecyclerView.ViewHolder(itemView){
//        val day:
//    }
//}